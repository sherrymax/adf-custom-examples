export class CustomInstanceListModelESResponse {
    id: string;
    name: string;
    status: string;
    // assignee: TaskAssignee;
}


// export class TaskAssignee {
//     id: string;
//     firstName: string;
//     lastName: string;
//     fullName: string;
//     email: string;
//     company: string;
// }


// export class ExecutionIdModel{
//     id: string;
// }


// export class CustomTaskListModel {
//     id: string;
//     instanceId: string;
//     subject: string;
//     status: string;
//     assignee: string;
// }