

declare const require;

import { Component, OnInit } from '@angular/core';
// import { AppConfigService, AuthenticationService } from '@alfresco/adf-core';
import { ContentService, ProcessContentService } from '@alfresco/adf-core';
import { ProcessService, ProcessFilterParamRepresentationModel } from '@alfresco/adf-process-services';
import { ProcessDataService } from '../../services/process-data.service';

import { NodesApiService, FormService, FormEvent } from '@alfresco/adf-core';
import { MinimalNodeEntryEntity } from 'alfresco-js-api';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { DialogComponent } from '../dialog/dialog.component';
import { GlobalVariables } from '../global-values/globals';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { ClickBoxService } from '../ocr-text-viewer/clickBox.service';
import * as stringSimilarity from 'string-similarity';
const jsonOCR2data = require('./img-rectangle.json');


@Component({
    selector: 'apw-user-mortgage',
    templateUrl: './user-mortgage.component.html',
    providers: [ProcessDataService, FormService],
    styleUrls: ['./user-mortgage.component.scss']
})
export class UserMortgageComponent implements OnInit {
    isSmallScreen = false;
    loading = false;
    processDefinitionId = '';
    requestNode: ProcessFilterParamRepresentationModel = {};
    processName = '';
    appId: number;
    mostRecentProcessInstanceID = '';
    currentProcessInstanceID = '';
    ignoredProcessInstanceIDList: string[] = [];
    showADFViewerForm = false;

    fetchedByADF = '';
    folderNodeID = '';
    fullName = '';
    email = '';
    accountNumber = '';
    profilePicURL = '';
    primaryMortageDocNodeId = '';
    newCustomerName = '';
    newProfilePicURL = '';
    newProfilePicNodeId = '';
    isDialogOpened = false;
    sub: Subscription;
    stopHeartBeat = false;
    taskID: string;
    showADFViewer = true;
    showSpinner = false;
    hasAnyTasks = true;
    jsonRecognition: string = '';
    instanceVariables: any[] = [];
    contentBlob: Blob;
    currentTaskName: string = "";

    constructor(
        private processService: ProcessService,
        private processDataService: ProcessDataService,
        private nodeService: NodesApiService,
        private dialog: MatDialog,
        private globalValues: GlobalVariables,
        private contentService: ContentService,
        private clickBoxService: ClickBoxService,
        private route: ActivatedRoute,
        private processContentService: ProcessContentService,
        private formService: FormService) {

        this.formService.formLoaded.subscribe((formEvent: FormEvent) => {
            this.showADFViewerForm = false;
            console.log('<== Form Event ==>');
            console.dir(formEvent);

            if (formEvent.form.name == 'Show Processed Documents') {

                setTimeout(() => {
                    let elementRecognition: any = document.getElementById('rekognitionresponse');
                    this.jsonRecognition = JSON.parse(elementRecognition.value);

                    let fileId = formEvent.form.json.fields[0].fields[2][1].value[0].id;
                    let fetch = this.processContentService.getFileRawContent(fileId);

                    fetch.subscribe((blob: Blob) => {
                        this.contentBlob = blob;
                        this.showADFViewerForm = true;
                    },
                        () => {
                        }
                    );
                }, 500);
            }


            if (formEvent.form.name == 'Verify Income' || formEvent.form.name == "Income Verification") {
                this.showADFViewerForm = false;

                let ocrFields = this.parseAnalyzeDocument(jsonOCR2data);
                ocrFields.forEach((currentField) => {

                    let keyText = currentField.keyText;
                    let keyValue = currentField.valueText;

                    console.log(`keyText : ${keyText} keyValue : ${keyValue}`);

                    let idField = this.findValueInFields(keyText, formEvent.form.fields);

                    if (idField) {
                        // console.log('idField' + idField.id + 'keyValue' + keyValue);
                        currentField.id = idField.id;
                    }
                });

                setTimeout(() => {
                    ocrFields.forEach((currentField) => {
                        let elementDOM: any = document.getElementById(currentField.id);
                        elementDOM.value = currentField.valueText;
                    });
                }, 500);
            }

        });

        this.formService.formEvents.subscribe((event: Event) => {
            if (event.type === 'click') {
                this.clickBoxService.seTextBoxToFill(event.target);
            }
        });
    }


    findValueInFields(keyText, fields) {
        let fieldInArray = undefined;

        fields.find((currentField) => {

            let similarity = stringSimilarity.compareTwoStrings(keyText, currentField.name);

            //console.log(`Form : "${currentField.name}" OCR : "${keyText}" result = ${similarity}` );

            if (similarity >= 0.9) {
                console.log(`Found corrispondency : ${currentField.name} OCR : ${keyText}`);
                fieldInArray = currentField;
                return true;
            }

            if (currentField.field && currentField.field.fields) {
                fieldInArray = this.findFieldInArrayField(keyText, currentField.field.fields);
                if (fieldInArray) {
                    return true
                }
            }
        });

        return fieldInArray;
    }

    findFieldInArrayField(keyText, fields) {
        let subElement = undefined
        Object.keys(fields).find((key) => {
            subElement = this.findValueInFields(keyText, fields[key]);
            if (subElement) {
                return true;
            }
        });

        if (subElement) {
            return subElement;
        }
    }

    parseAnalyzeDocument(analyzeDocument: any) {
        let formField: any[] = [];
        analyzeDocument.Blocks.forEach((currentRectangle: any) => {
            if (currentRectangle.EntityTypes && currentRectangle.EntityTypes.length > 0 && currentRectangle.EntityTypes[0] === 'KEY') {

                let valueRelation = currentRectangle.Relationships.find((currentRelationship: any) => {
                    return currentRelationship.Type === 'VALUE';
                });

                let valueObject = this.findFieldByKey(valueRelation.Ids[0], analyzeDocument);
                if (valueObject.Relationships) {
                    let valueText = this.findChildRelationValues(valueObject.Relationships, analyzeDocument);
                    let keyText = this.findChildRelationValues(currentRectangle.Relationships, analyzeDocument);

                    formField.push({
                        keyText: keyText,
                        keyId: currentRectangle.Id,
                        valueId: valueRelation.Ids[0],
                        valueText: valueText
                    })
                }
            }
        });

        return formField;
    }

    findFieldByKey(key: string, analyzeDocument: any): any {
        return analyzeDocument.Blocks.find((currentRectangle: any) => {
            return currentRectangle.Id === key
        });
    }

    findChildRelationValues(relationships: any, analyzeDocument: any): any {
        let accumulatorValues = '';
        relationships.forEach((currentRelation: any) => {
            if (currentRelation.Type === "CHILD") {

                currentRelation.Ids.forEach((currentId) => {
                    let currentChildElement = this.findFieldByKey(currentId, analyzeDocument);
                    if (currentChildElement.Text) {
                        if (accumulatorValues === '') {
                            accumulatorValues = currentChildElement.Text;
                        } else {
                            accumulatorValues = accumulatorValues + ' ' + currentChildElement.Text;

                        }
                    }
                });
            }
        });

        return accumulatorValues;
    }

    ngOnInit() {
        this.stopHeartBeat = false;
        this.showADFViewer = true;
        this.getMostRecentlyCreatedInstance();
        this.startHeartBeat();
        this.profilePicURL = '/resources/images/spinner.gif';
        this.sub = this.route.parent.params.subscribe(params => {
            this.appId = +params['appId'];
        });
    }

    ngOnDestroy() {
        this.stopHeartBeat = true;
    }

    showFile($event) {
        console.dir($event);
        this.primaryMortageDocNodeId = $event.value.entry.id;
    }

    startHeartBeat() {
        if (!this.stopHeartBeat) {
            setTimeout(() => {
                console.log('Starting Heartbeat engine');
                this.loading = true;
                this.getMostRecentlyCreatedInstance();
                this.startHeartBeat();
            }, 5000);
        }
    }

    getMostRecentlyCreatedInstance() {
        this.processDataService.getAllRunningProcessInstances().then(
            res => {
                this.mostRecentProcessInstanceID = res['data'][0]['id'];
                console.dir('Most Recent Instance ID = ' + this.mostRecentProcessInstanceID);

                if (this.ignoredProcessInstanceIDList.indexOf(this.mostRecentProcessInstanceID) != -1) {
                    console.log('*** Most recent customer is already greeted or ignored ***');
                    return;
                } else {
                    this.newProfilePicURL = '/resources/images/spinner.gif';
                    this.newProfilePicNodeId = '-i-dont-know-';
                    this.getAllProcessInstanceVariables(this.mostRecentProcessInstanceID);

                    setTimeout(() => {
                        this.newCustomerName = this.instanceVariables.filter(item => item.name === 'fullname')[0].value;
                        this.newProfilePicNodeId = this.instanceVariables.filter(item => item.name === 'profilePicNodeId')[0].value;

                        console.log('New Customer Name = ' + this.newCustomerName);
                        console.log('New Customer Profile Pic Node Id = ' + this.newProfilePicNodeId);
                        this.newProfilePicURL = this.contentService.getContentUrl(this.newProfilePicNodeId);
                        console.log('New Customer Profile Pic URL = ', this.newProfilePicURL);

                        this.openCowFishDialog(this.newCustomerName, this.newProfilePicURL, false);

                    }, 2500);
                }
            },
            error => {
                console.log(error.message || error);
            });
    }


    getNodeProperties() {
        this.getProcessInstanceVariableValue(this.currentProcessInstanceID, 'fetchedByADF');
        this.getProcessInstanceVariableValue(this.currentProcessInstanceID, 'folderNodeID');

        setTimeout(() => {
            console.log('isFetchedByADF = ' + this.fetchedByADF);
            console.log('folderNodeID = ' + this.folderNodeID);

            this.nodeService.getNode(this.folderNodeID).subscribe((entry: MinimalNodeEntryEntity) => {
                const node: MinimalNodeEntryEntity = entry;
                console.dir(node);
                this.fullName = node['properties']['cowfish:FullName'];
                this.accountNumber = node['properties']['cowfish:AccountNum'];
                this.email = node['properties']['cowfish:email'];
            });

            this.nodeService.getNodeChildren(this.folderNodeID, {}).subscribe(data => {
                console.log('Getting Node Children');
                console.dir(data);

                const profilePicNodeList = data.list.entries.filter(item => item.entry.name === 'profile_pic.jpg');
                const primaryMortgageDocNodeList = data.list.entries.filter(item => item.entry.name === 'Mortgage-Application.pdf');

                console.log('Getting Node List');
                console.dir(profilePicNodeList);

                if (profilePicNodeList.length > 0) {
                    const node_id = profilePicNodeList[0].entry.id;
                    this.profilePicURL = this.contentService.getContentUrl(node_id);

                    console.log(this.profilePicURL);
                }

                if (primaryMortgageDocNodeList.length > 0) {
                    this.primaryMortageDocNodeId = primaryMortgageDocNodeList[0].entry.id;
                }
            });
        }, 1000);
    }

    getAllProcessInstanceVariables(instanceID) {
        console.log('=== getAllProcessInstanceVariables START ===');

        this.instanceVariables = [];
        this.processService.getProcessInstanceVariables(instanceID).subscribe(
            res => {
                res.forEach(item => this.instanceVariables.push(item));
            }
        );

        console.log('=== getAllProcessInstanceVariables END ===');
        console.dir(this.instanceVariables);

    }

    getProcessInstanceVariableValue(instanceID, variableName) {
        this.processService.getProcessInstanceVariables(instanceID).subscribe(
            res => {
                console.log('<--- Process Variables --->');
                console.dir(res);
                for (let i = 0; i < res.length; i++) {
                    if (res[i].name == variableName) {
                        switch (variableName) {
                            case 'fetchedByADF': {
                                this.fetchedByADF = res[i].value;
                                break;
                            }
                            case 'folderNodeID': {
                                this.folderNodeID = res[i].value;
                                break;
                            }
                            case 'fullname': {
                                this.newCustomerName = res[i].value;
                                break;
                            }
                            case 'profilePicNodeId': {
                                this.newProfilePicNodeId = res[i].value;
                                break;
                            }
                        }
                    }
                }
            }
        );
    }

    openCowFishDialog(customerName: string, newCustomerProfilePicURL: string, isChatBotInvoked: boolean) {

        const dialogConfig = new MatDialogConfig();
        let dialogRef;

        this.ignoredProcessInstanceIDList.push(this.mostRecentProcessInstanceID);

        dialogConfig.disableClose = false;
        dialogConfig.autoFocus = true;
        dialogConfig.width = '1030px';
        dialogConfig.height = '460px';

        if (isChatBotInvoked) {
            dialogConfig.width = '550px';
            dialogConfig.height = '557px';
            dialogConfig.position = {
                top: '',
                bottom: '0',
                left: '',
                right: '0'
            };
        }
        dialogConfig.data = {
            customerName: customerName,
            newCustomerProfilePicURL: newCustomerProfilePicURL,
            isChatBotInvoked: isChatBotInvoked
        };
        dialogConfig.panelClass = 'adf-version-manager-dialog';


        if (!this.isDialogOpened) {
            this.isDialogOpened = true;
            dialogRef = this.dialog.open(DialogComponent, dialogConfig);
        }

        if (dialogRef) {
            dialogRef.afterClosed().subscribe(result => {
                this.isDialogOpened = false;
                console.log('<<< Dialog Closing Result >>> ');
                console.log('typeof result = ' + typeof (result));
                console.dir(result);
                if (result == true) {
                    console.log('officerDecision == ' + result);
                    this.globalValues.mostRecentPID = this.mostRecentProcessInstanceID;
                    this.currentProcessInstanceID = this.mostRecentProcessInstanceID;
                    this.showADFViewer = true;
                    this.showADFViewerForm = false;
                    this.getNodeProperties();
                } else {
                    console.log('User clicked the HOLD ON button...');
                    setTimeout(() => {
                        this.processService.cancelProcess(this.mostRecentProcessInstanceID).subscribe(res => {
                            this.processService.cancelProcess(this.mostRecentProcessInstanceID);
                            console.log('Instance ID ' + this.mostRecentProcessInstanceID + 'is DELETED');
                        });
                    }, 500);
                }
            });
        }
    }

    onTaskMode() {
        console.log("*** *** *** TASK MODE () *** *** ***");
        this.showSpinner = true;
        this.hasAnyTasks = true;

        setTimeout(() => {
            this.showADFViewer = false;
            this.processService.getProcessTasks(this.currentProcessInstanceID).subscribe(
                res => {
                    if (res.length == 0) {
                        console.log('NO TASKS FOUND..');
                        setTimeout(() => {
                            this.hasAnyTasks = false;
                            if (this.currentTaskName == 'Congratulations') {
                                this.nodeService.getNodeChildren(this.folderNodeID, {}).subscribe(data => {
                                    const preApprovalDocList = data.list.entries.filter(item => item.entry.name === 'preApproval.pdf');
                                    if (preApprovalDocList.length > 0) {
                                        this.primaryMortageDocNodeId = preApprovalDocList[0].entry.id;
                                    }
                                });

                                this.showADFViewer = true;
                                this.showADFViewerForm = false;
                                this.showSpinner = false;
                            }
                            else {
                                this.onTaskMode();
                            }
                        }, 500);
                    } else {
                        console.log('HURRAY.. TASK FOUND..');
                        console.dir(res);
                        this.taskID = res[0]['id'];
                        this.currentTaskName = res[0]['name'];
                        this.showSpinner = false;
                    }
                }
            );
        }, 500);
    }

    documentListNodeClicked($event) {
        this.showADFViewer = true;
    }
}


// const variables: ProcessInstanceVariable[] = [
//   { name: 'id', value: row.id },
//   { name: 'table_name', value: this.currentTab }
// ];

//Start Process
// setTimeout(() => {
//   this.processService.startProcess(processDefinitionId, name, null, null, variables).subscribe((processInstance: ProcessInstance) => {
//     console.log('ProcessInstance: ', processInstance);
//     this.processInstanceID = processInstance.id;
//     this.globalValues.currentProcessInstanceId = processInstance.id;
//   }, error => {
//     console.log('Error: ', error);
//   });
// }, 500);


//Get Tasks
// setTimeout(() => {
//   this.processService.getProcessTasks(this.processInstanceID)
//     .subscribe((taskList: TaskDetailsModel[]) => {
//       console.log('Instance ID from TaskList --> ' + this.processInstanceID);
//       console.log('Task List  = ', taskList)
//       console.log('Task ID = ' + taskList[0].id);
//       this.taskID = taskList[0].id;
//       this.globalValues.currentTaskId = this.taskID;
//     }, error => {
//       console.log('Error: ', error);
//     });
// }, 5000);


//Route to Task Details Page
// setTimeout(() => {
//   console.log('Starting navigation to TaskDetails');
//   this.router.navigateByUrl('taskdetails/' + this.appId + '/' + this.taskID);
// }, 5500);
//       }


//  }
