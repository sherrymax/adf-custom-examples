/*
 * Copyright 2005-2018 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { Component, Input, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { ProcessFilterService, FilterProcessRepresentationModel,
         ProcessInstanceVariable, ProcessService } from '@alfresco/adf-process-services';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AppConfigService, AlfrescoApiService, FormValues } from '@alfresco/adf-core';

@Component({
    selector: 'apw-create-process',
    templateUrl: './create-process.component.html',
    styleUrls: ['./create-process.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class CreateProcessComponent implements OnInit, OnDestroy {

    @Input()
    appId: string = null;

    sub: Subscription;
    defaultFilterId = '';

    defaultProcessDefinitionName: string;
    defaultProcessName: string;

    private processVariables: ProcessInstanceVariable[];

    formValues: FormValues  = {

        'usstate': {'id': 'TX', 'name': 'TX'}
    };

    constructor(private route: ActivatedRoute,
        private router: Router,
        private appConfig: AppConfigService,
        private processService: ProcessService,
        private alfrescoJsApi: AlfrescoApiService,
        private processFilterService: ProcessFilterService) {
            this.processVariables = [];
    }

    ngOnInit() {
        this.defaultProcessName = this.appConfig.get<string>('adf-start-process.name');
        this.defaultProcessDefinitionName = this.appConfig.get<string>('adf-start-process.processDefinitionName');

        console.log('defaultProcessName --> ' + this.defaultProcessName);
        console.log('defaultProcessDefinitionName --> ' + this.defaultProcessDefinitionName);


        this.sub = this.route.parent.params.subscribe(params => {
            this.appId = params['appId'];
            this.getDefaultProcessFilter(this.getAppId());
        });
    }

    ngOnDestroy() {
        if (this.sub) {
            this.sub.unsubscribe();
        }
    }

    backFromProcessCreation(event: any): void {
        console.log(event);
        this.createFolderFromTemplate(event.name, event.id);
    }

    getDefaultProcessFilter(appId: string): void {
        this.processFilterService.getProcessFilterByName('Running', +appId).subscribe(
            (res: FilterProcessRepresentationModel) => {
                this.defaultFilterId = res.id.toString();
            }
        );
    }

    getAppId(): string {
        return +this.appId === 0 ? null : this.appId;
    }

    createFolderFromTemplate(folderName: string, processId: string) {
        const url = 'slingshot/doclib/folder-templates';
        const localthis = this;
        this.alfrescoJsApi.getInstance().webScript.
                executeWebScript('POST', url, null, 'alfresco', 's', this.getRequestBody(folderName)).then(function (data) {
                  // console.log(data);
                  const localData: any = data;
                  // console.log(localData.persistedObject.split('Store/')[1]);
                  localthis.updateProcessDetails(localData.persistedObject.split('Store/')[1], processId);
        }, function (error) {
            console.log('Error' + error);
        });
    }

    getRequestBody(folderName: string) {
        const jsonBody: any = {
            alf_destination: 'workspace://SpacesStore/' + this.appConfig.get<string>('caseRootNodeId'),
            parentNodeRef: 'workspace://SpacesStore/' + this.appConfig.get<string>('caseRootNodeId'),
            prop_cm_description: folderName,
            prop_cm_name: folderName,
            prop_cm_title: folderName,
            sourceNodeRef:  'workspace://SpacesStore/' +   this.appConfig.get<string>('caseFolderTemplateId')
        };
        console.log(jsonBody);
        return jsonBody;
      }

      updateProcessDetails(cddfolderId: string, processId: string) {
        this.processVariables.push({name: 'folderId', value: cddfolderId, type: 'string'});
        this.processService.createOrUpdateProcessInstanceVariables(processId, this.processVariables)
        .subscribe( (variables: ProcessInstanceVariable[]) => {
            this.router.navigateByUrl('apps/' + this.appId + '/processes/' + this.defaultFilterId);
        }, error => {
          console.log('Error: ', error);
        });
      }
}
