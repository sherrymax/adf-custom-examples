/*
 * Copyright 2005-2018 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */


import { Component, ViewEncapsulation, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { ProcessInstance } from '@alfresco/adf-process-services';
import { MAT_DIALOG_DATA } from '@angular/material';
import { AppConfigService } from '@alfresco/adf-core';
import { DomSanitizer} from '@angular/platform-browser';

@Component({
    selector: 'dialog',
    templateUrl: './dialog.component.html',
    styleUrls: ['./dialog.component.scss'],
    encapsulation: ViewEncapsulation.None
})

export class DialogComponent implements OnInit {

    @Input()
    processInstanceId = '';

    @Output()
    navigate: EventEmitter<string> = new EventEmitter<string>();

    processInstanceDetails: ProcessInstance;
    processInstanceID: string;
    isChatBotInvoked: boolean;
    chatbotUrl: string = null;
    chatBotSafeURL: any;

    constructor(@Inject(MAT_DIALOG_DATA) public data: any,
                private appConfig: AppConfigService,
                private sanitizer: DomSanitizer) {
                    this.chatbotUrl = this.appConfig.get<string>('chat-bot-url');
                    this.chatBotSafeURL = this.sanitizer.bypassSecurityTrustResourceUrl(this.chatbotUrl) ;
                    console.dir(this.chatBotSafeURL);
                }

    ngOnInit() {
        this.processInstanceID = this.data['processInstanceID'];
        // this.newCustomerProfilePicURL = this.data['newCustomerProfilePicURL'];
        // this.isChatBotInvoked = this.data['isChatBotInvoked'];
        // this.chatbotUrl = this.appConfig.get<string>('chat-bot-url');
    }

    isRunning() {
        return false;

    }

}
