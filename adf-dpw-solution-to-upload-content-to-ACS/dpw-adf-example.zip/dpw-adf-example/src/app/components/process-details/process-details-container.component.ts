/*!
 * @license
 * Copyright 2016 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, ViewEncapsulation, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute, Router } from '@angular/router';
import { AppsProcessService } from '@alfresco/adf-core';
import {
    ProcessFilterService,
    ProcessInstance,
    ProcessService,
    FilterProcessRepresentationModel, 
    ProcessInstanceVariable} from '@alfresco/adf-process-services';
import { ToolbarIconEvent } from '../layout/toolbar/models/toolbar-icon-event';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { DialogComponent } from '../dialog/dialog.component';
import { APWProperties } from '../../models';

@Component({
    selector: 'apw-process-details-container',
    templateUrl: './process-details-container.component.html',
    styleUrls: ['./process-details-container.component.scss'],
    encapsulation: ViewEncapsulation.None
})

export class ProcessDetailsContainerComponent implements OnInit, OnDestroy {

    static DEFAULT_PROCESS_FILTER = 'Running';
    static SIDEBAR_DETAILS_TAB = 0;

    sub: Subscription;
    appId: number;
    processInstanceId: string;
    processInstanceDetails: ProcessInstance;
    showInfoDrawer = false;
    readOnlyForm = false;

    selectedTab: number;

    activeTab = ProcessDetailsContainerComponent.SIDEBAR_DETAILS_TAB;

    appName: string;

    folderId: string;

    showViewer = false;

    isDialogOpened = false;

    nodeId: string;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private location: Location,
        private processService: ProcessService,
        private appService: AppsProcessService,
        private processFilterService: ProcessFilterService,
        private dialog: MatDialog
    ) { }

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.appId = +params['appId'];
            this.processInstanceId = params['processInstanceId'];
            this.getAppName(this.getAppId());
            this.loadProcessDetails(this.processInstanceId);
            this.displayDocuments();
        });
    }

    private getAppId(): number {
        return +this.appId === 0 ? null : this.appId;
    }

    private loadProcessDetails(processInstanceId: string) {
        if (processInstanceId) {
            this.processService.getProcess(processInstanceId).subscribe(
                (res: ProcessInstance) => {
                    this.processInstanceDetails = res;
                    this.displayDocuments();
                }
            );
        }
    }

    refresh() {
        this.loadProcessDetails(this.processInstanceDetails.id);
    }

    getAppName(appId: number) {
        if (this.appId === 0) {
            this.appName = APWProperties.TASK_APP_NAME;
        } else {
            this.appService.getApplicationDetailsById(appId).subscribe(
                (res) => {
                    this.appName = res.name;
                }
            );
        }
    }

    hasProcessInstance(): boolean {
        return this.processInstanceDetails && !!this.processInstanceDetails.id;
    }

    isCompletedProcess(): boolean {
        return !!this.processInstanceDetails.ended;
    }

    isRunning(): boolean {
        return !this.isCompletedProcess();
    }

    onSelectedTab(tabIndex: number) {
        this.activeTab = tabIndex;
        this.selectedTab = tabIndex;
    }

    isDetailsTabActive() {
        return this.activeTab === ProcessDetailsContainerComponent.SIDEBAR_DETAILS_TAB;
    }

    onProcessNavigate(taskId) {
        this.router.navigate([`/taskdetails/${this.appId}/${taskId}`]);
    }

    getToolBarActionName(): string {
        return this.showInfoDrawer ? 'info' : '';
    }

    onToolbarIconClick(iconType: ToolbarIconEvent): void {
        if (iconType.isBackType()) {
            this.navigateByHistory();
        } else
        if (iconType.isCloseType()) {
            this.navigateToProcessList();
        } else
        if (iconType.isCancelType()) {
            this.processService.cancelProcess(this.processInstanceId).subscribe(
                () => {
                    this.navigateToProcessList();
                });
        } else
        if (iconType.isInfoType()) {
            this.showInfoDrawer = !this.showInfoDrawer;
        }
    }

    onCancelForm() {
        this.navigateByHistory();
    }

    private navigateByHistory(): void {
        this.location.back();
    }

    onNavigate(event) {
        this.navigateToProcessList();
    }

    navigateToProcessList(): void {
        this.processFilterService.getProcessFilterByName(ProcessDetailsContainerComponent.DEFAULT_PROCESS_FILTER, +this.appId).subscribe(
            (res: FilterProcessRepresentationModel) => {
                const filter = res;
                const navUrl: string = '/apps/' + this.appId + '/processes/' + filter.id;
                this.router.navigateByUrl(navUrl);
            }
        );
    }

    ngOnDestroy() {
        if (this.sub) {
            this.sub.unsubscribe();
        }
    }

    showPreview(event) {
        if (event.value.entry.isFile) {
            this.nodeId = event.value.entry.id;
            this.showViewer = true;
        }
    }

    displayDocuments() {
        // const items = event.value.getValue('variables');
        this.processService.getProcessInstanceVariables(this.processInstanceId).
                        subscribe( (items: ProcessInstanceVariable[]) => {
          console.log(items);
          const folderId: ProcessInstanceVariable = items.find(x => x.name === 'folderId');
          console.log('folderId ' + folderId);
          this.folderId = folderId.value;
          console.log(items.find(x => x.name === 'folderId').value);
          this.folderId = items.find(x => x.name === 'folderId').value;
        }, error => {
          console.log('Error: ', error);
        });
      }

      openCowFishDialog(processInstanceID: string) {

        const dialogConfig = new MatDialogConfig();
        let dialogRef;

        dialogConfig.disableClose = false;
        dialogConfig.autoFocus = true;
        dialogConfig.width = '1030px';
        dialogConfig.height = '460px';

    
        dialogConfig.data = {
            processInstanceID: processInstanceID
        };
        dialogConfig.panelClass = 'adf-version-manager-dialog';


        if (!this.isDialogOpened) {
            this.isDialogOpened = true;
            dialogRef = this.dialog.open(DialogComponent, dialogConfig);
        }

        if (dialogRef) {
            console.dir(dialogRef);
        }

        // if (dialogRef) {
        //     dialogRef.afterClosed().subscribe(result => {
        //         this.isDialogOpened = false;
        //         console.log('<<< Dialog Closing Result >>> ');
        //         console.log('typeof result = ' + typeof (result));
        //         console.dir(result);
        //         if (result == true) {
        //             console.log('officerDecision == ' + result);
        //             this.globalValues.mostRecentPID = this.mostRecentProcessInstanceID;
        //             this.currentProcessInstanceID = this.mostRecentProcessInstanceID;
        //             this.showADFViewer = true;
        //             this.showADFViewerForm = false;
        //             this.getNodeProperties();
        //         } else {
        //             console.log('User clicked the HOLD ON button...');
        //             setTimeout(() => {
        //                 this.processService.cancelProcess(this.mostRecentProcessInstanceID).subscribe(res => {
        //                     this.processService.cancelProcess(this.mostRecentProcessInstanceID);
        //                     console.log('Instance ID ' + this.mostRecentProcessInstanceID + 'is DELETED');
        //                 });
        //             }, 500);
        //         }
        //     });
        // }
    }
}
