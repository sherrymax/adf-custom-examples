import {
    Component,
    Input,
    OnChanges,
    SimpleChanges,
    ViewEncapsulation,
    ElementRef,
    OnInit,
    OnDestroy, ViewChild
} from '@angular/core';
import { ContentService } from '@alfresco/adf-core';
import { ClickBoxService } from './clickBox.service';

@Component({
    selector: 'adf-ocr-viewer',
    templateUrl: './imgViewer.component.html',
    styleUrls: ['./imgViewer.component.scss'],
    host: { 'class': 'adf-image-viewer' },
    encapsulation: ViewEncapsulation.None
})
export class ImgViewerComponent implements OnInit, OnChanges, OnDestroy {

    @Input()
    showToolbar = true;

    @Input()
    urlFile: string;

    @Input()
    blobFile: Blob;

    @Input()
    nameFile: string;

    @Input()
    jsonRecognition: any;

    rotate = 0;
    scaleX = 1.0;
    scaleY = 1.0;
    offsetX = 0;
    offsetY = 0;
    isDragged = false;
    showCanvas = true;

    @ViewChild('canvas')
    canvas: any;

    private drag = { x: 0, y: 0 };
    private delta = { x: 0, y: 0 };

    get transform(): string {
        return `scale(${this.scaleX}, ${this.scaleY}) rotate(${this.rotate}deg) translate(${this.offsetX}px, ${this.offsetY}px)`;
    }

    get currentScaleText(): string {
        return Math.round(this.scaleX * 100) + '%';
    }

    private element: HTMLElement;

    constructor(
        private contentService: ContentService,
        private clickBoxService: ClickBoxService,
        private el: ElementRef) {
    }

    drawBox(width: any, height: any) {
        const canvas: any = document.getElementById('adf-canvas');

        if (canvas) {
            canvas.style.width = width + 'px';
            canvas.style.height = height + 'px';


            const ctx = canvas.getContext('2d');

            ctx.canvas.width = width;
            ctx.canvas.height = height;

            this.jsonRecognition.blocks.forEach((currentRectangle: any) => {
                this.drawPolygon(currentRectangle, width, height, ctx);
            });
        }

    }

    drawPolygon(currentRectangle, width, height, ctx) {
        let containsChilds = false;
        if (currentRectangle.relationships && currentRectangle.relationships.length > 0 && currentRectangle.relationships[0].type === 'CHILD') {
            containsChilds = true;
        }
        const myPoints = currentRectangle.geometry.polygon;

        ctx.beginPath();
        myPoints.forEach((p, i) => {
            console.log(`width ${width} height ${height}`);

            let currentX = width * p.x;
            let currentY = height * p.y;

            if (containsChilds) {
                const margin = 12;
                if (i === 0) {
                    currentX = currentX - margin;
                    currentY = currentY - margin;
                } else if (i === 1) {
                    currentX = currentX + margin;
                    currentY = currentY - margin;
                } else if (i === 2) {
                    currentX = currentX + margin;
                    currentY = currentY + margin;
                } else if (i === 3) {
                    currentX = currentX - margin;
                    currentY = currentY + margin;
                }

            }

            // console.log(`currentX ${currentX} currentY ${currentY}`);
            if (i == 0) {
                //   console.log(`myctx.moveTo(${currentX},${currentY})`);
                ctx.moveTo(currentX, currentY);
            } else {
                // console.log(`myctx.lineTo(${currentX},${currentY})`);
                ctx.lineTo(currentX, currentY);
            }
        });

        ctx.closePath();
        ctx.lineWidth = 1;

        if (!containsChilds) {

            ctx.strokeStyle = "black";

            if (currentRectangle.confidence >= 90) {
                ctx.fillStyle = "rgba(0, 55, 255, 0.2)";
            } else {
                ctx.fillStyle = "rgba(255, 0, 0, 0.2)";
            }
            ctx.fill();
            ctx.stroke();
        } else {
            ctx.fillStyle = "rgba(255, 255, 0, 0.2)";
            ctx.fill();
            ctx.stroke();
        }
    }

    clickCanvas(mouseEvent: MouseEvent) {
        let lastword = '';
        console.log(`click canvas point ${mouseEvent.clientX} ${mouseEvent.clientY}`);

        const elementImage: any = document.getElementById('adf-viewer-image');

        const width = elementImage.width;
        const height = elementImage.height;

        this.jsonRecognition.blocks.forEach((currentRectangle: any, i) => {
            const vertx = [], verty = [];
            const myPoints = currentRectangle.geometry.polygon;

            let containsChilds = false;
            if (currentRectangle.relationships && currentRectangle.relationships.length > 0 && currentRectangle.relationships[0].type === 'CHILD') {
                containsChilds = true;
            }
            myPoints.forEach((p, i) => {
                let currentX = width * p.x;
                let currentY = height * p.y;

                if (containsChilds) {
                    const margin = 12;

                    if (i === 0) {
                        currentX = currentX - margin;
                        currentY = currentY - margin;
                    } else if (i === 1) {
                        currentX = currentX + margin;
                        currentY = currentY - margin;
                    } else if (i === 2) {
                        currentX = currentX + margin;
                        currentY = currentY + margin;
                    } else if (i === 3) {
                        currentX = currentX - margin;
                        currentY = currentY + margin;
                    }
                }

                vertx.push(currentX);
                verty.push(currentY);
            });

            if (this.pnpoly(vertx.length, vertx, verty, mouseEvent.offsetX, mouseEvent.offsetY)) {
                // console.log(`${currentRectangle.text}  has been clicked`);
                lastword = currentRectangle.text;
            }
        });

        this.clickBoxService.emitText(lastword);
    }

    pnpoly(nvert, vertx, verty, testx, testy) {
        let i, j, c = false;
        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            if (((verty[i] > testy) != (verty[j] > testy)) &&
                (testx < (vertx[j] - vertx[i]) * (testy - verty[i]) / (verty[j] - verty[i]) + vertx[i])) {
                c = !c;
            }
        }
        return c;
    }

    ngOnInit() {
        this.element = <HTMLElement>this.el.nativeElement.querySelector('#viewer-image');

        if (this.element) {
            this.element.addEventListener('mousedown', this.onMouseDown.bind(this));
            this.element.addEventListener('mouseup', this.onMouseUp.bind(this));
            this.element.addEventListener('mouseleave', this.onMouseLeave.bind(this));
            this.element.addEventListener('mouseout', this.onMouseOut.bind(this));
            this.element.addEventListener('mousemove', this.onMouseMove.bind(this));
        }
    }

    ngOnDestroy() {
        if (this.element) {
            this.element.removeEventListener('mousedown', this.onMouseDown);
            this.element.removeEventListener('mouseup', this.onMouseUp);
            this.element.removeEventListener('mouseleave', this.onMouseLeave);
            this.element.removeEventListener('mouseout', this.onMouseOut);
            this.element.removeEventListener('mousemove', this.onMouseMove);
        }
    }

    onMouseDown(event: MouseEvent) {
        event.preventDefault();
        this.isDragged = true;
        this.drag = { x: event.pageX, y: event.pageY };
    }

    onMouseMove(event: MouseEvent) {
        if (this.isDragged) {
            event.preventDefault();

            this.delta.x = event.pageX - this.drag.x;
            this.delta.y = event.pageY - this.drag.y;

            this.drag.x = event.pageX;
            this.drag.y = event.pageY;

            const scaleX = (this.scaleX !== 0 ? this.scaleX : 1.0);
            const scaleY = (this.scaleY !== 0 ? this.scaleY : 1.0);

            this.offsetX += (this.delta.x / scaleX);
            this.offsetY += (this.delta.y / scaleY);
        }
    }

    onMouseUp(event: MouseEvent) {
        if (this.isDragged) {
            event.preventDefault();
            this.isDragged = false;
        }
    }

    onMouseLeave(event: MouseEvent) {
        if (this.isDragged) {
            event.preventDefault();
            this.isDragged = false;
        }
    }

    onMouseOut(event: MouseEvent) {
        if (this.isDragged) {
            event.preventDefault();
            this.isDragged = false;
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        const blobFile = changes['blobFile'];
        if (blobFile && blobFile.currentValue) {
            this.urlFile = this.contentService.createTrustedUrl(this.blobFile);
            return;
        }
        if (!this.urlFile && !this.blobFile) {
            throw new Error('Attribute urlFile or blobFile is required');
        }

        if (this.jsonRecognition) {
            console.log(' this.jsonRecognition' + this.jsonRecognition);
        }
    }

    imgLoad() {
        const elementImage: any = document.getElementById('adf-viewer-image');
        const width = elementImage.width;
        const height = elementImage.height;
        this.drawBox(width, height);
        this.scaleX = this.scaleY = 1.6;
    }

    zoomIn() {
        const ratio = +((this.scaleX + 0.2).toFixed(1));
        this.scaleX = this.scaleY = ratio;
    }

    zoomOut() {
        let ratio = +((this.scaleX - 0.2).toFixed(1));
        if (ratio < 0.2) {
            ratio = 0.2;
        }
        this.scaleX = this.scaleY = ratio;
    }

    rotateLeft() {
        const angle = this.rotate - 90;
        this.rotate = Math.abs(angle) < 360 ? angle : 0;
    }

    rotateRight() {
        const angle = this.rotate + 90;
        this.rotate = Math.abs(angle) < 360 ? angle : 0;
    }

    reset() {
        this.rotate = 0;
        this.scaleX = 1.6;
        this.scaleY = 1.6;
        this.offsetX = 0;
        this.offsetY = 0;
    }

    show_canvas() {
        const canvas: any = document.getElementById('adf-canvas');
        canvas.style.display = ((canvas.style.display == 'block')?'none':'block');
    }
}
