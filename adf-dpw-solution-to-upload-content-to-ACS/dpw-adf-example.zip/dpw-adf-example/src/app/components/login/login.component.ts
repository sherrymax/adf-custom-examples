/*!
 * @license
 * Copyright 2016 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, ViewChild, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { AppConfigService, LogService, StorageService } from '@alfresco/adf-core';
import { Subscription } from 'rxjs/Rx';

@Component({
    selector: 'apw-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

    @ViewChild('alfrescologin')
    alfrescologin: any;

    providers = 'ALL';
    customValidation: any;

    disableCsrf = false;
    customMinLength = 2;

    appId: string;

    sub: Subscription;
    copyrightText = '\u00A9 2018 Alfresco Software, Inc. All Rights Reserved.';

    constructor(private router: Router,
        private storage: StorageService,
        private logService: LogService,
        private appConfig: AppConfigService) {

            this.customValidation = {
            username: ['', Validators.compose([
                Validators.required,
                Validators.minLength(this.customMinLength)
            ])],
            password: ['', Validators.required]
        };
    }

    ngOnInit() {
        this.copyrightText = this.appConfig.get<string>('adf-login.copyrightText', this.copyrightText);
        this.alfrescologin.addCustomValidationError('username', 'required', 'LOGIN.MESSAGES.USERNAME-REQUIRED');
        this.alfrescologin.addCustomValidationError('username', 'minlength', 'LOGIN.MESSAGES.USERNAME-MIN',
               { minLength: this.customMinLength });
        this.alfrescologin.addCustomValidationError('password', 'required', 'LOGIN.MESSAGES.PASSWORD-REQUIRED');

        this.initProviders();

    }

    initProviders() {
        if (this.storage.hasItem('providers')) {
            this.providers = this.storage.getItem('providers');
        } else {
            this.providers = this.appConfig.get('adf-login.providers', this.providers);
            this.storage.setItem('providers', this.providers);
        }
    }

    onLogin($event) {
        // this.router.navigate(['/']);
        this.appId = this.appConfig.get<string>('irtAppId');
        console.log(this.appId);
        this.router.navigate([`/apps/${this.appId}/processes`]);
    }

    onError($event) {
        this.logService.error($event);
    }

    validateForm($event) {

    }

}
