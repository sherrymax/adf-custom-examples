import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { AppConfigService } from '@alfresco/adf-core';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer} from '@angular/platform-browser';


@Pipe({ name: 'safe' })
export class SafePipe implements PipeTransform {
    
  constructor(private sanitizer: DomSanitizer) {}
  
  transform(url) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
} 

@Component({
  selector: 'apa-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent implements OnInit {

  private analyticsMenuItems:any[];
  private routeSub: Subscription;
  private analyticsId;
  analyticsURL;

  constructor(private appConfig: AppConfigService, private route: ActivatedRoute, private sanitizer: DomSanitizer) {}

  ngOnInit() {
    this.analyticsMenuItems = this.appConfig.get<any[]>('kibana-analytics');
    console.dir(this.analyticsMenuItems);

    this.routeSub = this.route.params.subscribe(params => {
      this.analyticsId = parseInt(params['analyticsId'])-1;
      console.log('Analytics ID from Component = '+this.analyticsId);
      console.log('Analytics URL from Component = '+this.analyticsMenuItems[this.analyticsId]['url']);
      this.analyticsURL = this.sanitizer.bypassSecurityTrustUrl(this.analyticsMenuItems[this.analyticsId]['url']);
      // this.analyticsURL = this.sanitizer.bypassSecurityTrustUrl(this.analyticsURL)['changingThisBreaksApplicationSecurity'];
      console.dir(this.analyticsURL);
    });

    console.dir(this.routeSub);

  }

}
