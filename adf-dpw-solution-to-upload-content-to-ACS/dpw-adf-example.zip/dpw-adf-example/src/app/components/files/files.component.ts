/*!
 * @license
 * Copyright 2016 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {
    Component, Input, OnInit, OnChanges, OnDestroy, ChangeDetectorRef,
    EventEmitter, ViewChild, SimpleChanges, Output, AfterViewChecked, ElementRef
} from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import {
    MinimalNodeEntity,
    NodePaging,
    Pagination,
    PathElementEntity,
    MinimalNodeEntryEntity,
    SiteEntry,
} from 'alfresco-js-api';
import {
    AuthenticationService, ContentService, TranslationService,
    FileUploadEvent, FolderCreatedEvent, LogService, NotificationService,
    UploadService, DataColumn, DataRow, UserPreferencesService,
    PaginationComponent, FormValues, DisplayMode, AppConfigService, FormEvent,
    FormService
} from '@alfresco/adf-core';

import { DocumentListComponent, PermissionStyleModel, BreadcrumbComponent } from '@alfresco/adf-content-services';

import { SelectAppsDialogComponent, StartProcessInstanceComponent } from '@alfresco/adf-process-services';

import { VersionManagerDialogAdapterComponent } from './version-manager-dialog-adapter.component';
import { MetadataDialogAdapterComponent } from './metadata-dialog-adapter.component';
import { Subscription } from 'rxjs/Subscription';

let DEFAULT_FOLDER_TO_SHOW = '-root-'; // any of these can be used : -root- , -my- , -sites-
const DEFAULT_FOLDER_DISPLAY_NAME = 'DPW Content Store';

@Component({
    selector: 'apw-files-component',
    templateUrl: './files.component.html',
    styleUrls: ['./files.component.scss']
})
export class FilesComponent implements OnInit, OnChanges, OnDestroy, AfterViewChecked {

    errorMessage: string = null;
    fileNodeId: any;
    showViewer = false;
    showVersions = false;
    isNodeSelected = false;
    displayMode = DisplayMode.List;
    appId: string;
    toolbarColor = 'default';
    el: ElementRef;
    @Input()
    // The identifier of a node. You can also use one of these well-known aliases: -my- | -shared- | -root-
    currentFolderId: string = DEFAULT_FOLDER_TO_SHOW;
    rootFolderId: string = DEFAULT_FOLDER_TO_SHOW;
    rootFolderDisplayName: string = DEFAULT_FOLDER_DISPLAY_NAME;
    formValues: FormValues = {};

    public contentInfoEntry: MinimalNodeEntryEntity;
    toggleSidebar = true;

    processAppId;

    @Input()
    selectionMode = 'multiple';

    @Input()
    multiselect = false;

    @Input()
    multipleFileUpload = true;

    @Input()
    folderUpload = false;

    @Input()
    acceptedFilesTypeShow = false;

    @Input()
    maxSizeShow = false;

    @Input()
    versioning = true;

    @Input()
    acceptedFilesType = '.jpg,.pdf,.js';

    @Input()
    maxFilesSize: number = null;

    @Input()
    enableUpload = true;

    @Input()
    nodeResult: NodePaging;

    @Input()
    pagination: Pagination;

    @Input()
    disableDragArea = false;

    @Output()
    documentListReady: EventEmitter<any> = new EventEmitter();

    @Output()
    changedPageSize: EventEmitter<Pagination> = new EventEmitter();

    @Output()
    changedPageNumber: EventEmitter<Pagination> = new EventEmitter();

    @Output()
    turnedNextPage: EventEmitter<Pagination> = new EventEmitter();

    @Output()
    turnedPreviousPage: EventEmitter<Pagination> = new EventEmitter();

    @Output()
    loadNext: EventEmitter<Pagination> = new EventEmitter();

    @Output()
    deleteElementSuccess: EventEmitter<any> = new EventEmitter();

    @ViewChild('documentList')
    documentList: DocumentListComponent;

    @ViewChild('startProcessComp')
    startProcessComp: StartProcessInstanceComponent;

    @ViewChild('breadCrumb')
    breadcrumb: BreadcrumbComponent;

    @ViewChild(PaginationComponent)
    standardPagination: PaginationComponent;

    permissionsStyle: PermissionStyleModel[] = [];
    infiniteScrolling: boolean;
    supportedPages: number[];
    appConf: Map<string, any>;
    appName = 'App';
    appDefaultLandingPage = 'files';

    private onCreateFolder: Subscription;
    private onEditFolder: Subscription;
    rootBreadcrumb: PathElementEntity = {'id' : 'pw', 'name' : 'Workspace'};
    showRecallProcessAction = false;
    linkedFaultRecall: string;
    showRecallProcessStartForm = false;
    docView = true;
    tempProcessStartDisable = false;

    constructor(private changeDetector: ChangeDetectorRef,
                private notificationService: NotificationService,
                private uploadService: UploadService,
                private contentService: ContentService,
                private dialog: MatDialog,
                private translateService: TranslationService,
                private router: Router,
                private logService: LogService,
                private preference: UserPreferencesService,
                private route: ActivatedRoute,
                public authenticationService: AuthenticationService,
                private appConfig: AppConfigService,
                private formService: FormService,
                el: ElementRef) {
                    this.el = el;
                    this.isNodeSelected = false;
    }

    showFile(event) {
        const entry = event.value.entry;
        if (entry && entry.isFile) {
            this.router.navigate([`/apps/${this.appId}/files`, entry.id, 'view']);
        }
    }

    nodeClick($event) {
        this.contentInfoEntry = $event.value.entry;
        this.isNodeSelected = !this.isNodeSelected;

        console.log("Node is clicked...");
        console.dir(this.contentInfoEntry);
        this.setRecallProcessFlag(this.contentInfoEntry);
    }

    onFolderChange($event) {
        this.contentInfoEntry = $event.value;
        this.setRecallProcessFlag(this.contentInfoEntry);
        this.currentFolderId = $event.value.id;
        this.router.navigate([`/apps/${this.appId}/files`, $event.value.id]);
    }

    onBreadcrumbNavigate(route: PathElementEntity) {
        this.onStartProcessCancel();
        if (route.id === 'pw') {
            this.router.navigate([`/apps`]);
        } else if (route.id === 'currApp') {
            this.router.navigate([`/apps/${this.appId}/${this.appDefaultLandingPage}`]);
        } else {
            this.router.navigate([`/apps/${this.appId}/files`, route.id]);
        }
    }

    toggleFolder() {
        this.multipleFileUpload = false;
        this.folderUpload = !this.folderUpload;
        return this.folderUpload;
    }

    ngOnInit() {

        DEFAULT_FOLDER_TO_SHOW = this.appConfig.get<string>('acs-wellsfargo-site-node-id');

        if (!this.pagination) {
            this.pagination = <Pagination>{
                maxItems: this.preference.paginationSize,
                skipCount: 0
            };
        }
        if (this.route) {
            const uriParts = this.router.url.split('/');
           // this.routeSub = this.route.params.subscribe(params => {
                // this.breadcrumb.route.unshift(this.rootBreadcrumb);
                this.appId = uriParts[2];
                this.appConf = this.appConfig.get<Map<string, any>>('appConfig');
                if (this.appConf && this.appConf[this.appId]) {
                    this.appName = this.appConf[this.appId]['name'];
                    this.appDefaultLandingPage = this.appConf[this.appId]['defaultLandingPage'];
                }
                if (uriParts.length > 4) {
                    this.currentFolderId = uriParts[4];
                    this.changeDetector.detectChanges();
                }
              // });
        }
        // this.disableDragArea = false;
        // this.uploadService.fileUploadComplete.asObservable().debounceTime(300).subscribe(value => this.onFileUploadEvent(value));
        this.uploadService.fileUploadDeleted.subscribe((value) => this.onFileUploadEvent(value));
        this.contentService.folderCreated.subscribe(value => this.onFolderCreated(value));
        this.onCreateFolder = this.contentService.folderCreate.subscribe(value => this.onFolderAction(value));
        this.onEditFolder = this.contentService.folderEdit.subscribe(value => this.onFolderAction(value));
        // this.supportedPages = this.preference.getDifferentPageSizes();
        // this.permissionsStyle.push(new PermissionStyleModel('document-list__create', PermissionsEnum.CREATE));
        // this.permissionsStyle.push(new PermissionStyleModel('document-list__disable', PermissionsEnum.NOT_CREATE, false, true));
        this.formService.formLoaded.subscribe(
            (e: FormEvent) => {
                for (const field of e.form.getFormFields()) {
                    if (field.id === 'faultid') {
                        const faultid = this.contentInfoEntry.properties['dru:faultid']
                            ? this.contentInfoEntry.properties['dru:faultid'] : '';
                        field.json.value = faultid;
                        field.value = faultid;
                    }
                    if (field.id === 'modelid') {
                        const modelid = this.contentInfoEntry.properties['dru:faultid']
                        ? this.contentInfoEntry.properties['dru:faultmodel'] : '';
                        field.json.value = modelid;
                        field.value = modelid;
                    }
                }

            }
        );

    }

    ngOnDestroy() {
        if(this.onCreateFolder)this.onCreateFolder.unsubscribe();
        if(this.onEditFolder)this.onEditFolder.unsubscribe();
    }

    ngAfterViewChecked() {
        if (this.breadcrumb && this.breadcrumb.route && this.breadcrumb.route.length > 0 && this.breadcrumb.route[0]['id'] !== 'pw') {
            const appBreadcrumb = {'id' : 'currApp', 'name' : this.appName};
            this.breadcrumb.route.unshift(appBreadcrumb);
            this.breadcrumb.route.unshift(this.rootBreadcrumb);
            if (!this.hasSelection(this.documentList.selection)) {
                this.contentInfoEntry = this.breadcrumb.folderNode;
                this.setRecallProcessFlag(this.contentInfoEntry);
            }
        }
        if (this.startProcessComp && this.startProcessComp.processDefinitions && !this.startProcessComp.selectedProcessDef) {
             this.startProcessComp.selectedProcessDef = this.startProcessComp.processDefinitions.filter(
                pd => pd.key === 'ProductRecall')[0];
                this.startProcessComp.name = 'Product Recall for: ' + this.contentInfoEntry.properties['dru:faultid'];
                // adding the following as the widget is still there even after setting showTitle=false !
                this.el.nativeElement.querySelector('.mat-card-title').style.display = 'none';
        }
    }

    setRecallProcessFlag(contentEntry: MinimalNodeEntryEntity) {
        if (this.contentInfoEntry && this.contentInfoEntry.properties
            && this.contentInfoEntry.properties['dru:faultid']) {
            if (!this.contentInfoEntry.properties['dru:faultrecallref']) {
                this.showRecallProcessAction = true;
                this.linkedFaultRecall = null;
            } else {
                this.showRecallProcessAction = false;
                this.linkedFaultRecall = this.contentInfoEntry.properties['dru:faultrecallref'];
            }
        } else {
            this.showRecallProcessAction = false;
            this.linkedFaultRecall = null;
        }
    }
    ngOnChanges(changes: SimpleChanges) {
        if (changes.nodeResult && changes.nodeResult.currentValue) {
            this.nodeResult = <NodePaging>changes.nodeResult.currentValue;
            this.pagination = this.nodeResult.list.pagination;
        }
        if (!this.pagination) {
            this.giveDefaultPaginationWhenNotDefined();
        }
    }

    giveDefaultPaginationWhenNotDefined() {
        this.pagination = <Pagination> {
            maxItems: this.preference.paginationSize,
            skipCount: 0,
            totalItems: 0,
            hasMoreItems: false
        };
    }

    getCurrentDocumentListNode(): MinimalNodeEntity[] {
        if (this.documentList.folderNode) {
            return [{ entry: this.documentList.folderNode }];
        } else {
            return [];
        }
    }

    onNavigationError(err: any) {
        if (err) {
            this.errorMessage = err.message || 'Navigation error';
        }
    }

    resetError() {
        this.errorMessage = null;
    }

    onFileUploadEvent(event: FileUploadEvent) {
        if (event && event.file.options.parentId === this.documentList.currentFolderId) {
            this.documentList.reload();
        }
    }

    onFolderCreated(event: FolderCreatedEvent) {
        this.logService.log('FOLDER CREATED');
        this.logService.log(event);
        if (event && event.parentId === this.documentList.currentFolderId) {
            this.documentList.reload();
        }
    }

    onFolderAction(node) {
        this.logService.log(node);
        if (node && node.parentId === this.documentList.currentFolderId) {
            this.documentList.reload();
        }
    }

    handlePermissionError(event: any) {
        this.translateService.get('PERMISSON.LACKOF', {
            permission: event.permission,
            action: event.action,
            type: event.type
        }).subscribe((message) => {
            this.notificationService.openSnackMessage(
                message,
                4000
            );
        });
    }

    handleUploadError(event: any) {
        this.notificationService.openSnackMessage(
            event,
            4000
        );
    }

    emitReadyEvent(event: any) {
        if (this.pageIsEmpty(event)) {
            this.standardPagination.goPrevious();
        } else {
            this.documentListReady.emit(event);
            this.pagination = event.list.pagination;
        }
    }

    pageIsEmpty(node: NodePaging) {
        return node && node.list && node.list.entries.length === 0;
    }

    onContentActionError(errors) {
        const errorStatusCode = JSON.parse(errors.message).error.statusCode;
        let translatedErrorMessage: any;

        switch (errorStatusCode) {
            case 403:
                translatedErrorMessage = this.translateService.get('OPERATION.ERROR.PERMISSION');
                break;
            case 409:
                translatedErrorMessage = this.translateService.get('OPERATION.ERROR.CONFLICT');
                break;
            default:
                translatedErrorMessage = this.translateService.get('OPERATION.ERROR.UNKNOWN');
        }

        this.notificationService.openSnackMessage(translatedErrorMessage.value, 4000);
    }

    onContentActionSuccess(message) {
        const translatedMessage: any = this.translateService.get(message);
        this.notificationService.openSnackMessage(translatedMessage.value, 4000);
    }

    onDeleteActionSuccess(message) {
        this.uploadService.fileDeleted.next(message);
        this.deleteElementSuccess.emit();
    }

    onManageVersions(event) {
        const contentEntry = event.value.entry;

        if (this.contentService.hasPermission(contentEntry, 'update')) {
            this.dialog.open(VersionManagerDialogAdapterComponent, {
                data: { contentEntry },
                panelClass: 'adf-version-manager-dialog',
                width: '630px'
            });
        } else {
            const translatedErrorMessage: any = this.translateService.get('OPERATION.ERROR.PERMISSION');
            this.notificationService.openSnackMessage(translatedErrorMessage.value, 4000);
        }
    }

    onManageMetadata(event) {
        console.log('** ** ** ** ** **');
        console.dir(event);

        const contentEntry = event.value.entry;

        if (this.contentService.hasPermission(contentEntry, 'update')) {
            this.dialog.open(MetadataDialogAdapterComponent, {
                data: { contentEntry },
                panelClass: 'adf-metadata-manager-dialog',
                width: '630px'
            });
        } else {
            const translatedErrorMessage: any = this.translateService.get('OPERATION.ERROR.PERMISSION');
            this.notificationService.openSnackMessage(translatedErrorMessage.value, 4000);
        }
    }

    onSiteChange(site: SiteEntry) {
        this.currentFolderId = site.entry.guid;
    }

    getDocumentListCurrentFolderId() {
        return this.documentList.currentFolderId || DEFAULT_FOLDER_TO_SHOW;
    }

    hasSelection(selection: Array<MinimalNodeEntity>): boolean {
        return selection && selection.length > 0;
    }

    hasOneFileSelected(): boolean {
        const selection: Array<MinimalNodeEntity> = this.documentList.selection;
        const hasOneFileSelected = selection && selection.length === 1 && selection[0].entry.isFile;
        return hasOneFileSelected;
    }

    userHasPermissionToManageVersions(): boolean {
        const selection: Array<MinimalNodeEntity> = this.documentList.selection;
        return this.contentService.hasPermission(selection[0].entry, 'update');
    }

    getNodeNameTooltip(row: DataRow, col: DataColumn): string {
        if (row) {
            return row.getValue('name');
        }
        return null;
    }

    canEditFolder(selection: Array<MinimalNodeEntity>): boolean {
        if (selection && selection.length === 1) {
            const entry = selection[0].entry;

            if (entry && entry.isFolder) {
                return this.contentService.hasPermission(entry, 'update');
            }
        }
        return false;
    }

    canCreateContent(parentNode: MinimalNodeEntryEntity): boolean {
        if (parentNode) {
            return this.contentService.hasPermission(parentNode, 'create');
        }
        return false;
    }

    onChangePageSize(event: Pagination): void {
        this.preference.paginationSize = event.maxItems;
        this.changedPageSize.emit(event);
    }

    onChangePageNumber(event: Pagination): void {
        this.changedPageNumber.emit(event);
    }

    onNextPage(event: Pagination): void {
        this.turnedNextPage.emit(event);
    }

    loadNextBatch(event: Pagination) {
        this.loadNext.emit(event);
    }

    onPrevPage(event: Pagination): void {
        this.turnedPreviousPage.emit(event);
    }

    toogleGalleryView(): void {
        if (this.displayMode === DisplayMode.List) {
            this.displayMode = DisplayMode.Gallery;
        } else {
            this.displayMode = DisplayMode.List;
        }
    }

    startProcesAction($event) {
        console.log("*** File Properties *** ");
        console.dir($event.value.entry);

        this.docView = false;
        this.formValues['file'] = $event.value.entry; // the name of formValue is 'file'. This name must be same as the field in the APS Form.
        this.formValues['nodeid'] = $event.value.entry.id;

        const dialogRef = this.dialog.open(SelectAppsDialogComponent, {
            width: '630px',
            panelClass: 'adf-version-manager-dialog'
        });

        dialogRef.afterClosed().subscribe(selectedProcessApp => {
            this.processAppId = selectedProcessApp.id;
        });
    }

    startRecallProces() {
        this.showRecallProcessStartForm = true;
        this.docView = false;
    }

    onStartProcessCancel() {
        this.docView = true;
        this.tempProcessStartDisable = false;
        this.processAppId = null;
        this.showRecallProcessStartForm = false;
    }

    onStartProcessSuccess() {
        this.docView = true;
        this.processAppId = null;
        this.tempProcessStartDisable = true;
        this.showRecallProcessStartForm = false;
    }
}
