/*!
 * @license
 * Copyright 2016 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Injectable } from '@angular/core';
import { AlfrescoApiService } from '@alfresco/adf-core';
import { AlfrescoApi } from 'alfresco-js-api';
import { Observable } from 'rxjs/Observable';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable()
export class DatamodelService {

  alfrescoApi: AlfrescoApi;
  urlBase: string;
  datamodelUrl: string;

  constructor(private alfrescoApiService: AlfrescoApiService,
    private httpClient: HttpClient) {
    this.alfrescoApi = this.alfrescoApiService.getInstance();
    this.urlBase = this.alfrescoApi.config.hostBpm;
    this.datamodelUrl = this.urlBase + '/activiti-app/api/enterprise/custom-api/datamodels/';
  }

  getDataList(dataModelName: string, dataModelId: string): Observable<any> {
    const url = this.datamodelUrl + dataModelId + '/entities/' + dataModelName;
    let headers = new HttpHeaders();
    if (this.alfrescoApi.config && this.alfrescoApi.config.ticketBpm) {
      headers = new HttpHeaders({
        'Authorization': this.alfrescoApi.config.ticketBpm
      });
    }
    const httpOptions = {
      headers: headers
    };
    return this.httpClient.get(url, httpOptions)
      .map((res: Response) => res)
      .catch((error: any) => Observable.throw(error || 'Server error'));
  }
}
