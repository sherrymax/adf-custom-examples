/*
 * Copyright 2005-2018 Alfresco Software, Ltd. All rights reserved.
 *
 * License rights for this program may be obtained from Alfresco Software, Ltd.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */


// Imports
import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers, Response } from '@angular/http';
import { AppConfigService } from '@alfresco/adf-core';

// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class ProcessDataService {
    options: RequestOptions;

    // Resolve HTTP using the constructor
    constructor(private http: Http, private appConfgiService: AppConfigService) {

    }

    getAllRunningProcessInstances(): Promise<any> {
        console.log('Starting getAllRunningProcessInstances() --> ');
        const filterRunningAsc = {
            'appDefinitionId': this.appConfgiService.get<string>('cowfish-app-id'),
            'state': 'all',
            'sort': 'created-desc',
            'size': 1
        };

        const headers = new Headers({ 'Content-Type': 'application/json' });
            headers.append('Authorization', 'Basic ZGVtbzpkZW1v');

        const options = new RequestOptions({ headers: headers });
        const body = JSON.stringify(filterRunningAsc);
        const apiUrlBase = this.appConfgiService.get<string>('aps-rest-url');

        return this.http.post(apiUrlBase, body, options).toPromise()
            .then(this.extractData)
            .catch(this.handleErrorPromise);
    }

    private extractData(res: Response) {
        const body = res.json();
        return body || {};
    }

    private handleErrorPromise(error: Response | any) {
        console.error(error);
        return Promise.reject(error.message || error);
    }

}
