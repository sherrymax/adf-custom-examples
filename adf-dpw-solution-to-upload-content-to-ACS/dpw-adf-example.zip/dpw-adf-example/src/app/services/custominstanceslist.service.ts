/* * * ./app/comments/services/comment.service.ts * * */
// Imports
import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { CustomInstanceListModelESResponse } from '../models/custominstanceslist.model';
import { Observable } from 'rxjs/Rx';
import { AppConfigService } from '@alfresco/adf-core';
// import { HttpHeaders, HttpClient } from '@angular/common/http';


// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class CustomInstancesListService {
    private esUrlBase;
    private claimEventUri;
    private customTaskListUrl;

    // Resolve HTTP using the constructor
    constructor(private http: Http, private appConfig: AppConfigService) {
        this.esUrlBase = this.appConfig.get<string>('elasticsearchUrl');
        this.claimEventUri = '/insuranceindex/claimevent/';
        // this.customTaskListUrl = this.esUrlBase + this.claimEventUri + '_search?size=500';
        this.customTaskListUrl = 'http://localhost:3000/activiti-app/api/enterprise/historic-tasks/query';

        console.log(this.esUrlBase);
        console.log(this.claimEventUri);
        console.log(this.customTaskListUrl);

    }


    getInstancesByFilterID(appIdNumber: Number, filterIdNumber: Number): Observable<CustomInstanceListModelESResponse[]> {


        // return this.http.get(this.customTaskListUrl + queryParam)
        //     .map((res: Response) => res.json().hits.hits)
        //     .catch((error: any) => Observable.throw(error.json().error || 'Server error'));

        let appId = ''+appIdNumber;
        let filterId = ''+filterIdNumber;


        const body = {
                "appDefinitionId":appId,
                "filterId":filterId
        };

        console.log('*** *** ***');
        console.dir(body);

        const httpOptions = {
            headers: new Headers({
            'Authorization':'Basic ZGVtbzpkZW1v',
            'Content-Type':'application/json',
            'Accept':'application/json'
            })
        };
        return this.http.post('/activiti-app/api/enterprise/process-instances/filter', body, httpOptions)
            .map((res: any) => res)
            .catch((error: any) => Observable.throw(error.json.error || 'Server error'));



    }

    // getCustomTaskDetails(id: string): Observable<CustomInstanceListModelESResponse> {
    //     let claimDetailsUrl = this.esUrlBase + this.claimEventUri + id;
    //     return this.http.get(claimDetailsUrl)
    //         .map((res: Response) => res.json())
    //         .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    // }

    // getExecutionIdByInstanceId(id: string): Observable<ExecutionIdModel[]> {
    //     // let claimDetailsUrl = this.esUrlBase + this.claimEventUri + id; 
    //     const httpOptions = {
    //         headers: new Headers({
    //         'Authorization':'Basic ZGVtbzpkZW1v'
    //         })
    //     };
    //     let executionIDUrl = 'http://localhost:3000/activiti-app/api/runtime/executions?tenantId=tenant_1&processInstanceId='+id;
    //     return this.http.get(executionIDUrl, httpOptions)
    //         .map((res: Response) => res)
    //         .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    // }

    // triggerBoundarMessageEventByExecutionId(id: string): Observable<ExecutionIdModel[]> {
    //     const body = {
    //         "action":"messageEventReceived",
    //         "messageName":"saveFaceMessage"
    //         }
    //     const httpOptions = {
    //         headers: new Headers({
    //         'Authorization':'Basic ZGVtbzpkZW1v',
    //         'cache-control':'no-cache',
    //         'content-type':'application/json'
    //         })
    //     };
    //     let putURL = '/activiti-app/api/runtime/executions/'+id+'?tenantId=tenant_1';
    //     return this.http.put(putURL, body, httpOptions)
    //         .map((res: any) => res)
    //         .catch((error: any) => Observable.throw(error.json.error || 'Server error'));
    // }


}

