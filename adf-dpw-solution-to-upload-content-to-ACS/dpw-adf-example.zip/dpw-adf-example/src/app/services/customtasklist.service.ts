/* * * ./app/comments/services/comment.service.ts * * */
// Imports
import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { CustomTaskListModelESResponse } from '../models/customtasklist.model';
import { Observable } from 'rxjs/Rx';
import { AppConfigService } from '@alfresco/adf-core';
// import { HttpHeaders, HttpClient } from '@angular/common/http';


// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class CustomTaskListService {
    private taskDetailsUrl;
    

    // Resolve HTTP using the constructor
    constructor(private http: Http, private appConfig: AppConfigService) {
        this.taskDetailsUrl = this.appConfig.get<string>('aps-task-details-url')
        console.log(this.taskDetailsUrl);
    }

    getTaskDetails(taskId: string): Observable<CustomTaskListModelESResponse> {
        console.log('<<< Starting getTaskDetails >>>');
        this.taskDetailsUrl = this.appConfig.get<string>('aps-task-details-url')+taskId;


        const httpOptions = {
            headers: new Headers({
            'Authorization':'Basic ZGVtbzpkZW1v'
            })
        };

        return this.http.get(this.taskDetailsUrl, httpOptions)
            .map((res: Response) => res.json())
            .catch((error: any) => Observable.throw(error.json().error || 'Server error'));



    }


}

