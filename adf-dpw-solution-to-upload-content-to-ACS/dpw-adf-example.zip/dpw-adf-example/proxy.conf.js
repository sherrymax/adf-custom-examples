module.exports = {
  "/activiti-app": {
    "target": "http://1.2.3.4",
    "secure": false,
    "pathRewrite": {
      "^/activiti-app/activiti-app": ""
    },
    "changeOrigin": true
  },
  "/alfresco": {
    "target": "http://1.2.3.4",
    "secure": false,
    "pathRewrite": {
      "^/alfresco/alfresco": ""
    },
    "changeOrigin": true,
    // workaround for REPO-2260
    onProxyRes: function (proxyRes, req, res) {
      const header = proxyRes.headers['www-authenticate'];
      if (header && header.startsWith('Basic')) {
          proxyRes.headers['www-authenticate'] = 'x' + header;
      }
    }
  },
};
