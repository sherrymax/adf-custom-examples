# Create Alfresco Repository
These following steps can be followed with muti-tenant license 
1. Login to APS as admin. 
2. Navigate to Identity management and click on Tenants
3. Select a tenant.
4. Click the Alfresco Repositories  and configure your on-premise Alfresco repsoitories by adding it.
5. Logout admin and login as normal user in APS
6. Navigate to Profile and you can see the Alfresco Repositories with 'No account configured - click to configure account'.
7. Click the Alfresco Repositories and give the logged-in user credentials   
