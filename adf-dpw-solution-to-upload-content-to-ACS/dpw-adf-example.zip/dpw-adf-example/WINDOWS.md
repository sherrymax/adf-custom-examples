#Windows Installation of *Alfresco Angular 2 Components* project 

See https://github.com/Alfresco/alfresco-ng2-components/blob/master/Prerequisites.md
